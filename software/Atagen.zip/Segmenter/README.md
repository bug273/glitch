# Segmenter
multidirectional broken pixelsorter
    
    pixel directionality is determined by ranges that are
    split from multiples of brightness threshold. 
    (eg. thresh@64: 0-64 sorts up, 65-127 sorts right, & so on)
    
    sorting can be modulated live using controls,
    or sequenced using a combination of cycle + dswitch options.
    sorts can be bound by clicking and dragging to select area.
    
    please note looping sorts are possible/likely/desirable;
    you may need to shuffle threshold during sort to 'complete'.
    enable choice option for pattern generation/broken sort.
