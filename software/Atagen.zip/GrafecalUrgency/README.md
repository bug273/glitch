# GrafecalUrgency
a sketch that utilises a bug in Processing's OGL renderer when not looping to effectively spew memory to the display window.
