# VectorBend
input: VectorBend.py [filename] [frequency] [amplitude] [source coord] [dest coord] [outname] <br>
A script to apply sine modulations to Inkscape-formatted plain SVG 1.1 files. The 'source'/'dest' coords are 0 (x) or 1 (y).
