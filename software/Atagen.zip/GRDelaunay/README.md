# GRDelaunay
GRDelaunay is an image processing utility that applies a delaunay triangulation to a given image. the original code was a proof of concept by Abe Gonzalez, modified by Clif Pottberg, Adam Tuerff and myself to be an operable utility. requires G4P and gifAnimation libraries.
