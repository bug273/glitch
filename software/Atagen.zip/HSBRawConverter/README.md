# HSBRawConverter
A sketch to convert files to and from 24bpp HSB raw. Can be compiled immediately into a portable program.
