# FileHandlingExamples
An example I wrote for a friend on how to use file lists to operate on a directory, save dynamically, &amp; iterate through multiple GIFs in Processing. 
