# ManSort
ManSort is a flexible, live controlled voronoi-bound pixelsorter. it includes regular and manhattan voronoi bounding (its original purpose, hence the name).
it also has experimental corruptive functions.
it is a collaboration between myself and Adam Tuerff, including some adapted code from Abe Gonzales and CodexDesign.
