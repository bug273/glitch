# strokes
pencil stroke (multimode)

a Processing sketch that draws a pencil-like rendition of an image fed to it. this version includes multiple draw and colour read modes with sequencable mode-switching.
original: http://www.openprocessing.org/sketch/145401
adaptation to images, Tomasz Sulej, generateme.blog@gmail.com: https://gist.github.com/tsulej/c661deac6708dc835f46
sequencing, alternate modes, general clutter - rob mac
