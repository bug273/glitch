# RGBShift
RGBShift is a script that allows you to manually displace RGB layers (wholly on XY axis).
also contains several modifiers that are similar to the 'wordpad effect' as performed on interleaved and planar bitmaps.
