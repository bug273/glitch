# IPCamScan
a sketch to use an IP camera (which a phone can act as, using apps such as IPWebcam) to generate a slit scan image.
adapted from code by FormandCode.
